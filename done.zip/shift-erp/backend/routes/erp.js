// routes/erp.js
const express = require('express');
const db      = require('../db');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware);

// ── DEPARTMENTS ───────────────────────────────────────────
router.get('/departments', (req, res) => {
  try { res.json(db.all('SELECT * FROM departments ORDER BY id')); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
router.post('/departments', (req, res) => {
  try {
    const { name } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Name required' });
    const r = db.run('INSERT INTO departments (name) VALUES (?)', [name.trim()]);
    res.json({ id: r.lastInsertRowid, name: name.trim() });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Already exists' });
    res.status(500).json({ error: e.message });
  }
});
router.put('/departments/:id', (req, res) => {
  try { db.run('UPDATE departments SET name=? WHERE id=?', [req.body.name, req.params.id]); res.json({ message: 'Updated' }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
router.delete('/departments/:id', (req, res) => {
  try { db.run('DELETE FROM departments WHERE id=?', [req.params.id]); res.json({ message: 'Deleted' }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ROLES ─────────────────────────────────────────────────
router.get('/roles', (req, res) => {
  try { res.json(db.all('SELECT * FROM roles ORDER BY id')); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
router.post('/roles', (req, res) => {
  try {
    const { name } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Name required' });
    const r = db.run('INSERT INTO roles (name) VALUES (?)', [name.trim()]);
    res.json({ id: r.lastInsertRowid, name: name.trim() });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Already exists' });
    res.status(500).json({ error: e.message });
  }
});
router.put('/roles/:id', (req, res) => {
  try { db.run('UPDATE roles SET name=? WHERE id=?', [req.body.name, req.params.id]); res.json({ message: 'Updated' }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
router.delete('/roles/:id', (req, res) => {
  try { db.run('DELETE FROM roles WHERE id=?', [req.params.id]); res.json({ message: 'Deleted' }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});

// ── SHIFTS ────────────────────────────────────────────────
router.get('/shifts', (req, res) => {
  try { res.json(db.all('SELECT * FROM shifts ORDER BY id')); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
router.post('/shifts', (req, res) => {
  try {
    const { name, start_time, end_time, type } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: 'Name required' });
    const r = db.run('INSERT INTO shifts (name,start_time,end_time,type) VALUES (?,?,?,?)',
      [name.trim(), start_time||'', end_time||'', type||'Morning']);
    res.json({ id: r.lastInsertRowid, name: name.trim(), start_time, end_time, type });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Already exists' });
    res.status(500).json({ error: e.message });
  }
});
router.put('/shifts/:id', (req, res) => {
  try {
    const { name, start_time, end_time, type } = req.body;
    db.run('UPDATE shifts SET name=?,start_time=?,end_time=?,type=? WHERE id=?',
      [name, start_time||'', end_time||'', type||'Morning', req.params.id]);
    res.json({ message: 'Updated' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
router.delete('/shifts/:id', (req, res) => {
  try { db.run('DELETE FROM shifts WHERE id=?', [req.params.id]); res.json({ message: 'Deleted' }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});

// ── EMPLOYEES ─────────────────────────────────────────────
router.get('/employees', (req, res) => {
  try {
    const emps = db.all('SELECT * FROM employees ORDER BY id');
    const att  = db.all('SELECT * FROM attendance ORDER BY date DESC');
    const result = emps.map(e => ({
      ...e,
      attendance: att.filter(a => a.employee_id === e.id).map(a => ({ date: a.date, status: a.status }))
    }));
    res.json(result);
  } catch(e) { console.error(e); res.status(500).json({ error: e.message }); }
});
router.post('/employees', (req, res) => {
  try {
    const { name, emp_id, phone, department, role, shift } = req.body;
    if (!name || !emp_id) return res.status(400).json({ error: 'Name and Employee ID required' });
    const r = db.run('INSERT INTO employees (name,emp_id,phone,department,role,shift) VALUES (?,?,?,?,?,?)',
      [name.trim(), emp_id.trim(), phone||'', department||'', role||'', shift||'']);
    res.json({ id: r.lastInsertRowid, name, emp_id, phone, department, role, shift, attendance: [] });
  } catch(e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Employee ID already exists' });
    res.status(500).json({ error: e.message });
  }
});
router.put('/employees/:id', (req, res) => {
  try {
    const { name, emp_id, phone, department, role, shift } = req.body;
    db.run('UPDATE employees SET name=?,emp_id=?,phone=?,department=?,role=?,shift=? WHERE id=?',
      [name, emp_id, phone||'', department||'', role||'', shift||'', req.params.id]);
    res.json({ message: 'Updated' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
router.delete('/employees/:id', (req, res) => {
  try {
    db.run('DELETE FROM attendance WHERE employee_id=?', [req.params.id]);
    db.run('DELETE FROM employees WHERE id=?', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ATTENDANCE ────────────────────────────────────────────
router.post('/attendance', (req, res) => {
  try {
    const { employee_id, date, status } = req.body;
    if (!employee_id || !date || !status) return res.status(400).json({ error: 'Missing fields' });
    const existing = db.get('SELECT id FROM attendance WHERE employee_id=? AND date=?', [employee_id, date]);
    if (existing) {
      db.run('UPDATE attendance SET status=? WHERE employee_id=? AND date=?', [status, employee_id, date]);
    } else {
      db.run('INSERT INTO attendance (employee_id,date,status) VALUES (?,?,?)', [employee_id, date, status]);
    }
    res.json({ message: 'Saved', employee_id, date, status });
  } catch(e) { console.error(e); res.status(500).json({ error: e.message }); }
});

// ── DASHBOARD ─────────────────────────────────────────────
router.get('/dashboard', (req, res) => {
  try {
    const now = new Date();
    const today = now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
    const departments = db.get('SELECT COUNT(*) as c FROM departments').c;
    const roles       = db.get('SELECT COUNT(*) as c FROM roles').c;
    const shifts      = db.get('SELECT COUNT(*) as c FROM shifts').c;
    const employees   = db.get('SELECT COUNT(*) as c FROM employees').c;
    const present     = db.get("SELECT COUNT(*) as c FROM attendance WHERE date=? AND status='Present'", [today]).c;
    const absent      = db.get("SELECT COUNT(*) as c FROM attendance WHERE date=? AND status='Absent'", [today]).c;
    const onLeave     = db.get("SELECT COUNT(*) as c FROM attendance WHERE date=? AND status='Leave'", [today]).c;
    res.json({ departments, roles, shifts, employees, present, absent, onLeave });
  } catch(e) { console.error(e); res.status(500).json({ error: e.message }); }
});

module.exports = router;
