// routes/auth.js
const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../db');
const { authMiddleware, SECRET } = require('../middleware/auth');

const router = express.Router();

router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
    const user = db.get('SELECT * FROM users WHERE username = ?', [username]);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    if (!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '8h' });
    res.json({ token, user: { id: user.id, username: user.username, role: user.role } });
  } catch(e) { console.error(e); res.status(500).json({ error: e.message }); }
});

router.get('/me', authMiddleware, (req, res) => {
  try {
    const user = db.get('SELECT id, username, role, created_at FROM users WHERE id = ?', [req.user.id]);
    res.json(user);
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.put('/change-password', authMiddleware, (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) return res.status(400).json({ error: 'Both passwords required' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Min 6 characters' });
    const user = db.get('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!bcrypt.compareSync(currentPassword, user.password)) return res.status(401).json({ error: 'Current password incorrect' });
    const hash = bcrypt.hashSync(newPassword, 10);
    db.run('UPDATE users SET password = ? WHERE id = ?', [hash, req.user.id]);
    res.json({ message: 'Password updated' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.put('/change-username', authMiddleware, (req, res) => {
  try {
    const { newUsername, password } = req.body;
    if (!newUsername || !password) return res.status(400).json({ error: 'New username and password required' });
    if (newUsername.length < 3) return res.status(400).json({ error: 'Min 3 characters' });
    const user = db.get('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Password incorrect' });
    const taken = db.get('SELECT id FROM users WHERE username = ? AND id != ?', [newUsername, req.user.id]);
    if (taken) return res.status(409).json({ error: 'Username already taken' });
    db.run('UPDATE users SET username = ? WHERE id = ?', [newUsername, req.user.id]);
    const newToken = jwt.sign({ id: user.id, username: newUsername, role: user.role }, SECRET, { expiresIn: '8h' });
    res.json({ message: 'Username updated', token: newToken, username: newUsername });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.post('/create-user', authMiddleware, (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    const { username, password, role = 'staff' } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
    const exists = db.get('SELECT id FROM users WHERE username = ?', [username]);
    if (exists) return res.status(409).json({ error: 'Username taken' });
    const hash = bcrypt.hashSync(password, 10);
    const r = db.run('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', [username, hash, role]);
    res.json({ message: 'User created', id: r.lastInsertRowid });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.get('/users', authMiddleware, (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    res.json(db.all('SELECT id, username, role, created_at FROM users'));
  } catch(e) { res.status(500).json({ error: e.message }); }
});

router.delete('/users/:id', authMiddleware, (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
    if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
    db.run('DELETE FROM users WHERE id = ?', [req.params.id]);
    res.json({ message: 'Deleted' });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
