// db.js — uses sql.js (pure JS, no Python/build tools needed)
const path = require('path');
const fs   = require('fs');
const bcrypt = require('bcryptjs');

const initSqlJs = require('sql.js');
const DB_PATH = path.join(__dirname, 'shift_erp.db');

let db; // will be set after async init

async function initDB() {
  const SQL = await initSqlJs();

  // Load existing DB file if it exists
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
    console.log('✅ Loaded existing database from', DB_PATH);
  } else {
    db = new SQL.Database();
    console.log('✅ Created new database at', DB_PATH);
  }

  // Create tables
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      username   TEXT    NOT NULL UNIQUE,
      password   TEXT    NOT NULL,
      role       TEXT    NOT NULL DEFAULT 'staff',
      created_at TEXT    DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS departments (
      id   INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT    NOT NULL UNIQUE
    );
    CREATE TABLE IF NOT EXISTS roles (
      id   INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT    NOT NULL UNIQUE
    );
    CREATE TABLE IF NOT EXISTS shifts (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL UNIQUE,
      start_time TEXT,
      end_time   TEXT,
      type       TEXT DEFAULT 'Morning'
    );
    CREATE TABLE IF NOT EXISTS employees (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL,
      emp_id     TEXT NOT NULL UNIQUE,
      phone      TEXT,
      department TEXT,
      role       TEXT,
      shift      TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS attendance (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER NOT NULL,
      date        TEXT    NOT NULL,
      status      TEXT    NOT NULL,
      UNIQUE(employee_id, date)
    );
  `);

  // Seed admin if not exists
  const adminRows = db.exec("SELECT id FROM users WHERE username='admin'");
  if (!adminRows.length || !adminRows[0].values.length) {
    const hash = bcrypt.hashSync('admin123', 10);
    db.run("INSERT INTO users (username, password, role) VALUES ('admin', ?, 'admin')", [hash]);
    save();
    console.log('✅ Default admin created → username: admin  password: admin123');
  } else {
    console.log('✅ Admin already exists');
  }

  return db;
}

// Save DB to file after every write
function save() {
  const data = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

// ── QUERY HELPERS ─────────────────────────────────────────
// Returns array of row objects
function all(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
      rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
  } catch(e) {
    console.error('DB all() error:', e.message, '\nSQL:', sql);
    throw e;
  }
}

// Returns single row object or null
function get(sql, params = []) {
  const rows = all(sql, params);
  return rows.length ? rows[0] : null;
}

// Runs INSERT/UPDATE/DELETE, returns { lastInsertRowid, changes }
function run(sql, params = []) {
  try {
    db.run(sql, params);
    save();
    const lastId = db.exec('SELECT last_insert_rowid() as id')[0]?.values[0][0];
    return { lastInsertRowid: lastId };
  } catch(e) {
    console.error('DB run() error:', e.message, '\nSQL:', sql);
    throw e;
  }
}

module.exports = { initDB, all, get, run, save };
