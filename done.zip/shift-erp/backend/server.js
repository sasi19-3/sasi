// server.js
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const { initDB } = require('./db');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Init DB first, then start server
initDB().then(() => {
  app.use('/api/auth', require('./routes/auth'));
  app.use('/api/erp',  require('./routes/erp'));

  app.get(/^(?!\/api).*/, (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
  });

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => {
    console.log(`\n🚀 Shift ERP running at http://localhost:${PORT}`);
    console.log(`   Login: admin / admin123\n`);
  });
}).catch(err => {
  console.error('❌ Failed to initialize database:', err);
  process.exit(1);
});
